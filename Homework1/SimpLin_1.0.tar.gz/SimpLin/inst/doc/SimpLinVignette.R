## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(SimpLin)

## ---- eval = FALSE------------------------------------------------------------
#  require(devtools)
#  install_github("KarissaPalmer/STAT600/Homework1/SimpLin", build_vignettes = TRUE)
#  library(SimpLin)

## -----------------------------------------------------------------------------
data(mtcars)
head(mtcars, n = 3)

## -----------------------------------------------------------------------------
plot(mtcars$hp, mtcars$mpg)

## -----------------------------------------------------------------------------
mod_output<- SimpLinR(x = mtcars$hp, y = mtcars$mpg)

## -----------------------------------------------------------------------------
mod_output$Conf_Ints
mod_output$SEs

## -----------------------------------------------------------------------------
mod_output$Coefficients

## -----------------------------------------------------------------------------
plot(mtcars$hp, mod_output$Residuals)

## -----------------------------------------------------------------------------
plot(mtcars$hp, mtcars$mpg, col = 'red')
points(mtcars$hp, mod_output$Pred_Vals, col = 'blue')

## ---- error = TRUE------------------------------------------------------------
#Vectors of different lengths
SimpLinR(x = c(1,1), y = c(1))

#Non-numeric entries in a vector
SimpLinR(x = c(1,1), y = c(1, 'b'))

